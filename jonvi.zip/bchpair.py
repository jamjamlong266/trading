from jonvi_api import JonviClient
from binanceapi import BinanceClient
import time
import request
import random



binance_api_key="8ovOuiaMx7NwodKm34xTH4Dq62zWZgB8Whnkojgx9ZfZLEhhPIlPAqFuOqzP6cIg"  #kk
binance_secret_key="WXDjj0Ws6jLrTEyozR9mXbOCYIcFigojokRIB1q5uNkytDFU1ccYci4EIzIEUdA7" #kk
binance=BinanceClient(binance_api_key,binance_secret_key)

api_key='NWVlM2M1NGItNjgxMS00N2Q1LWIwZWQtYzQzMmRhMzc4YzVk'
api_secret='NTc3OWJiNmUtZDA3YS00OTRmLThiNGItZGZmZDQzNjA2MzY2'
kk = JonviClient(api_key, api_secret)

#trading_pair1={"btcusdt","ltcusdt","ethusdt","bchusdt"}
trading_pair1={"btcusdt"}
trading_pair2={"ethbtc","ltcbtc","bchbtc"}


resp=kk.get_access_token()
print resp["data"]


for i in range(1,10000):
    for pair in trading_pair1:
        
        resp=kk.sell_orderbook(pair,5)
        resp=kk.buy_orderbook(pair,5)
        resp=kk.balance()
        print resp
        if pair=="bchusdt":
            binance.get_order_book(symbol="BCCUSDT")
        
        else:
            binance.get_order_book(symbol=pair.upper())
    
    #    resp=kk.place_order(pair,0.05,binance.ask1+,side)  # side 1 Buy, 2 Sell
    
        #time.sleep(random.randint(1,30))
    
    for pair in trading_pair2:
        
        resp=kk.sell_orderbook(pair,5)
        resp=kk.buy_orderbook(pair,5)
        resp=kk.balance()
        print resp
        if pair=="bchbtc":
            binance.get_order_book(symbol="BCCBTC")
        
        else:
            binance.get_order_book(symbol=pair.upper())
    
        side=random.randint(1,2) # 1 Buy, 2 Sell
    
        price=round(binance.bid1+(0.5-random.random())*0.05*binance.bid1,8)
        print price
    
        # resp=kk.place_order(pair,0.15,price,side)
    
        #time.sleep(random.randint(1,30))
    
    pair="jeemyr"
    resp=kk.sell_orderbook(pair,5)
    resp=kk.buy_orderbook(pair,5)
    resp=kk.balance()
    print resp
    
    side=random.randint(1,2) # 1 Buy, 2 Sell
    bid1 = 0.44
    price=round(bid1+(0.5-random.random())*0.1,2)
    print price
    
    # resp=kk.place_order(pair,15,price,side)
    
    pair="jeusdt"
    resp=kk.sell_orderbook(pair,5)
    resp=kk.buy_orderbook(pair,5)
    resp=kk.balance()
    print resp
    
    side=random.randint(1,2) # 1 Buy, 2 Sell
    bid1 = 0.11
    price=round(bid1+(0.5-random.random())*0.1,2)
    print price
    
    # resp=kk.place_order(pair,15,price,side)
    
    #time.sleep(random.randint(1,30))